Strava export readme - not an activity file
